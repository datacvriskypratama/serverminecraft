### IDE integration

1. import checkstyle.xml configuration file
2. set "checkstyle.header.file" property to the absolute path of license.header file
3. add [checkstyle-nonstandard-0.1.0.jar](http://search.maven.org/remotecontent?filepath=com/github/shyiko/checkstyle-nonstandard/0.1.0/checkstyle-nonstandard-0.1.0.jar) to the list of third-party check providers