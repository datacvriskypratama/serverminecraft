mysql-bin.sakila.gz is a product of [Sakila Sample Database](http://dev.mysql.com/doc/sakila/en/index.html)'s
sakila-schema.sql and sakila-data.sql (Copyright (c) 2006 MySQL AB) in form of binary log.
